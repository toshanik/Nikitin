git init
touch Readme.txt
nano Readme.txt
git add -A
git commit
git branch iss01
git checkout iss01
nano Readme.txt
git add -A
git commit
