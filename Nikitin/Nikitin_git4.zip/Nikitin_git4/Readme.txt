git init
git config --global user.name "NikitinAA"
git config --global user.email "nik.ant38@mail.ru"
git config --local core.editor nano
git config --local http.proxy http://proxyUsername:proxyPassword@proxy.server.com:port
git config --global alias.lo "log —oneline —all —graph —decorate"