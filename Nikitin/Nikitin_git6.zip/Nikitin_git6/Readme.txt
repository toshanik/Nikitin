git init
touch Readme.txt
nano Readme.txt
git add -A
git commit
git tag -a Test -m FirstTest
git log
git tag -a Test2 -m SecondTest e94198ea2667c985c9329f237e3aed466f15ed6a
git log
git tag Test3 e94198ea2667c985c9329f237e3aed466f15ed6a
git log


Git decribe выдает строку. Например:
$ git describe master
v1.6.2-20-g8c5b85c
Она расшифровывается как: 
коммит основан на ветке с тегом v1.6.2, 
после этого произошло 20 коммитов, 
g - git, 
Короткий хэш текущего коммита.: 8c5b85c